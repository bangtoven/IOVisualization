﻿namespace Framework.UI.Controls
{
    /// <summary>
    /// The wizard mode.
    /// </summary>
    public enum WizardMode
    {
        None,
        Linear,
        Tree
    }
}
