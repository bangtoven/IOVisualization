﻿namespace Framework.UI.Controls
{
    public enum IconSize
    {
        Small,
        Medium,
        Large,
        VeryLarge,
        Custom
    }
}
