﻿namespace Framework.UI.Controls
{
    public enum MessageDialogType
    {
        Light,
        Dark,
        Accent
    }
}
