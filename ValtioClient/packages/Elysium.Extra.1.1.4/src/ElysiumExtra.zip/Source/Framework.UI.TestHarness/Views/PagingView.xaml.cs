﻿namespace Framework.UI.TestHarness.Views
{
    /// <summary>
    /// Interaction logic for PagingView.xaml
    /// </summary>
    public partial class PagingView
    {
        public PagingView()
        {
            InitializeComponent();
        }
    }
}
