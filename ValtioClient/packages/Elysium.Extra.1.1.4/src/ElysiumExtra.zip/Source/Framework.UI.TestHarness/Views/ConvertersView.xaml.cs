﻿namespace Framework.UI.TestHarness.Views
{
    /// <summary>
    /// Interaction logic for ConvertersView.xaml
    /// </summary>
    public partial class ConvertersView
    {
        public ConvertersView()
        {
            InitializeComponent();
        }
    }
}
