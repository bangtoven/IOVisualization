﻿namespace Framework.UI.TestHarness.Views
{
    /// <summary>
    /// Interaction logic for BackgroundView.xaml
    /// </summary>
    public partial class BackgroundView
    {
        public BackgroundView()
        {
            InitializeComponent();
        }
    }
}
