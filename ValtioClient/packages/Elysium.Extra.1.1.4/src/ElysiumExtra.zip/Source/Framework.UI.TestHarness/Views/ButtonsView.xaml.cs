﻿namespace Framework.UI.TestHarness.Views
{
    /// <summary>
    /// Interaction logic for ButtonsView.xaml
    /// </summary>
    public partial class ButtonsView
    {
        public ButtonsView()
        {
            InitializeComponent();
        }
    }
}
