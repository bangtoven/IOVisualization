﻿namespace Framework.UI.TestHarness.Views
{
    /// <summary>
    /// Interaction logic for TreeViewView.xaml
    /// </summary>
    public partial class TreeViewView
    {
        public TreeViewView()
        {
            InitializeComponent();
        }
    }
}
