﻿namespace Framework.UI.TestHarness.Views
{
    /// <summary>
    /// Interaction logic for BordersView.xaml
    /// </summary>
    public partial class BordersView
    {
        public BordersView()
        {
            InitializeComponent();
        }
    }
}
