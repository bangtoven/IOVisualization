﻿namespace Framework.UI.TestHarness.Views
{
    /// <summary>
    /// Interaction logic for ListViewView.xaml
    /// </summary>
    public partial class ListViewView
    {
        public ListViewView()
        {
            InitializeComponent();
        }
    }
}
