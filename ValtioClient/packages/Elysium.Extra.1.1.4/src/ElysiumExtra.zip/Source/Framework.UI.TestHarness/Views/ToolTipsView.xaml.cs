﻿namespace Framework.UI.TestHarness.Views
{
    /// <summary>
    /// Interaction logic for ToolTipsView.xaml
    /// </summary>
    public partial class ToolTipsView
    {
        public ToolTipsView()
        {
            InitializeComponent();
        }
    }
}
