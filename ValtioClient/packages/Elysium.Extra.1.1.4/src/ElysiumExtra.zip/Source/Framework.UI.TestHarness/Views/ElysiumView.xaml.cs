﻿namespace Framework.UI.TestHarness.Views
{
    /// <summary>
    /// Interaction logic for ElysiumView.xaml
    /// </summary>
    public partial class ElysiumView
    {
        public ElysiumView()
        {
            InitializeComponent();
        }
    }
}
